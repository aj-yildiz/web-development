import Layout from "../components/Layout";
import PageHeader from "../components/PageHeader";
import Footer from "../components/Footer";

import React, { useState } from "react";
import { useAuth } from "../context/AuthContext";

const Login = () => {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(""); // Add error state

  const handleLogin = async (e) => {
    e.preventDefault(); // Prevent form reload
    try {
      const response = await fetch(`${process.env.REACT_APP_API_URL}/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }), // Send email and password as JSON
      });

      if (!response.ok) {
        throw new Error("Invalid login credentials");
      }

      const data = await response.json();

      console.log("Login response:", data); // Debug API response

      // Call AuthContext login with user and token
      login(data.user, data.token);
    } catch (error) {
      console.error("Login error:", error.message);
      setError("Invalid credentials."); // Display error to user
    }
  };

  return (
    <Layout>
      <PageHeader
        title="Bytes Odyssey"
        subtitle="A Blog Platform About Life and Code"
        backgroundImage="/static/img/vechicle.jpg"
      />

      <section className="container mt-4">
        <form onSubmit={handleLogin}>
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required // Ensure input is required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required // Ensure input is required
          />
          {error && <p style={{ color: "red" }}>{error}</p>} {/* Display error */}
          <button type="submit">Login</button>
        </form>
      </section>

      <Footer />
    </Layout>
  );
};

export default Login;
